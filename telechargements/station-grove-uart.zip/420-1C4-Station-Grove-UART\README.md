# Station Grove à deux Arduino, reliés par UART

*Cours 420-1C4 — Objets connectés · Par VE2CUY · Version 1.0 (2026-11-20)*

Ce projet met en place **deux Arduino qui travaillent ensemble**, reliés par un câble série
(UART), et utilise **les 17 modules Grove** de la bibliothèque du cours. Chaque module peut être
activé, désactivé et essayé à partir d'un menu, dans le moniteur série.

Il sert de **référence** : pour voir comment brancher et programmer chaque module, comment faire
dialoguer deux cartes, et comment écrire un programme qui fait beaucoup de choses « en même temps »
sans jamais utiliser `delay()`.

---

## Contenu

1. [Vue d'ensemble](#1--vue-densemble)
2. [Les modules et leurs branchements](#2--les-modules-et-leurs-branchements)
3. [Démarrer dans le simulateur](#3--démarrer-dans-le-simulateur)
4. [Démarrer sur le vrai matériel](#4--démarrer-sur-le-vrai-matériel)
5. [Les menus](#5--les-menus)
6. [Visite guidée : essayer chaque module](#6--visite-guidée--essayer-chaque-module)
7. [Le protocole entre les deux cartes](#7--le-protocole-entre-les-deux-cartes)
8. [Comment le code est organisé](#8--comment-le-code-est-organisé)
9. [Pièges et leçons apprises](#9--pièges-et-leçons-apprises)
10. [Pour aller plus loin](#10--pour-aller-plus-loin)
11. [Les fichiers du projet](#11--les-fichiers-du-projet)

---

## 1 – Vue d'ensemble

La station imite un petit **système de surveillance d'un local** :

- le **poste de capteurs** (Arduino **UNO**) est installé dans le local. Il mesure la
  température, l'humidité, la pression et l'heure, surveille les mouvements et le bouton, et agit
  sur place (relais, DEL, écran);
- la **centrale** (Arduino **MEGA**) est à l'accueil. Elle affiche tout ce que le poste lui
  envoie, sonne l'alerte, contrôle l'accès par badge RFID et peut joindre Internet par Wi-Fi.

```
        POSTE DE CAPTEURS (UNO)                              CENTRALE (MEGA)
  ┌──────────────────────────────────┐               ┌──────────────────────────────────┐
  │ Bouton ............. D2          │               │ D2 ......... Afficheur 4-Digit   │
  │ DEL rouge (PWM) .... D3          │  câble Grove  │ D4 ......... Barre de 10 DEL     │
  │ Relais ............. D4          │    (UART)     │ D6 ......... Buzzer              │
  │ Détecteur mouvement  D5          │               │ D8 ......... DEL bleue           │
  │ DEL verte .......... D7          │ D8 ◄──────► UART2           │
  │ Potentiomètre ...... A0          │  9600 bauds   │ UART1 ...... Module Wi-Fi ── Internet
  │ LCD RGB, SHT31,                  │               │ UART3 ...... Lecteur RFID        │
  │ BME280, horloge .... I2C         │               │ I2C ........ LCD 20x4            │
  └──────────────────────────────────┘               └──────────────────────────────────┘
       mesures et événements  ──────────────►
                              ◄──────────────  commandes (relais, DEL verte, badge accepté)
```

Ce qui se passe, par exemple :

| Quand… | Le UNO… | La centrale MEGA… |
|---|---|---|
| on appuie sur le **bouton** | allume ou éteint sa DEL verte, LCD orange | bip court, barre orange, « Bouton UNO : 3 » |
| le **détecteur** voit un mouvement | LCD rouge « MOUVEMENT! » | alerte : bips répétés, barre rouge clignotante |
| on tourne le **potentiomètre** | la DEL rouge varie d'intensité | la barre de DEL se remplit, l'afficheur montre le % |
| on présente un **badge autorisé** | ferme le relais 3 s (la « porte » s'ouvre) | mélodie qui monte, barre verte |
| on présente un **badge inconnu** | LCD rouge « Acces refuse » | deux notes graves, barre rouge |
| chaque seconde | lit l'horloge et l'envoie | l'afficheur 4-Digit montre l'heure, le LCD aussi |
| chaque 2 secondes | lit le SHT31 et le BME280 | le LCD 20x4 affiche température, humidité, pression |

---

## 2 – Les modules et leurs branchements

Les 17 modules de la bibliothèque du cours, répartis sur les deux cartes :

| # | Module | Carte | Prise | Bibliothèque | Ce qu'on en fait |
|---|---|---|---|---|---|
| 1 | Bouton | UNO | D2 | — | Compte les appuis, bascule la DEL verte |
| 2 | DEL rouge | UNO | D3 | — | Intensité réglée par le potentiomètre (PWM) |
| 3 | Relais | UNO | D4 | — | « Gâche » de la porte, commandable à distance |
| 4 | Détecteur de mouvement | UNO | D5 | — | Déclenche l'alerte |
| 5 | DEL verte | UNO | D7 | — | Bouton, menu, ou commande du MEGA |
| 6 | Potentiomètre | UNO | A0 | — | Réglage de 0 à 100 % |
| 7 | LCD RGB (16x2) | UNO | I2C | Grove - LCD RGB Backlight | Heure, mesures; couleur selon l'événement |
| 8 | Capteur SHT31 | UNO | I2C | Grove SHT31 | Température et humidité |
| 9 | Capteur BME280 | UNO | I2C | Grove - Barometer Sensor BME280 | Température et pression |
| 10 | Horloge RTC DS1307 | UNO | I2C | Grove - RTC DS1307 | L'heure, même Arduino éteint (pile) |
| 11 | Afficheur 4-Digit | MEGA | D2 | TM1637V2 (fournie, dans `lib/`) | Heure, potentiomètre ou température |
| 12 | RGB LED Stick (10 DEL) | MEGA | D4 | Adafruit NeoPixel | Niveau du potentiomètre, arc-en-ciel, effets |
| 13 | Buzzer | MEGA | D6 | — (`tone()`) | Mélodies et alertes |
| 14 | DEL bleue | MEGA | D8 | — | Clignote à chaque message reçu du UNO |
| 15 | LCD 20x4 I2C | MEGA | I2C | LiquidCrystal_I2C | Tableau de bord de la centrale |
| 16 | Module Wi-Fi | MEGA | UART1 | WiFiEsp | Requête à un site Web |
| 17 | Lecteur RFID 125 kHz | MEGA | UART3 | — (lecture du port série) | Contrôle d'accès par badge |
| — | Câble entre les cartes | UNO D8 ↔ MEGA UART2 | | SoftwareSerial (UNO) | Le lien UART |

**Une prise Grove porte deux broches.** La prise D2 du UNO donne accès à D2 et à D3. Un module
simple n'utilise que la première broche : la prise D3 reste donc libre pour la DEL rouge. Certains
modules utilisent les deux broches : l'afficheur 4-Digit (CLK et DIO) et le câble UART (TX et RX).

**Le bus I2C est partagé.** Les quatre modules I2C du UNO sont sur les mêmes deux fils (SDA et
SCL). Chacun a son **adresse** : LCD RGB 0x3E et 0x62, SHT31 0x44, BME280 0x76, horloge 0x68. Le
programme parle à l'un ou à l'autre par son adresse; c'est la bibliothèque de chaque module qui
s'en occupe.

Les broches, délais et réglages sont regroupés dans `include/config.h` de chaque projet.

---

## 3 – Démarrer dans le simulateur

Le projet est prêt pour l'extension **Simulateur Arduino Grove** (version 1.2.0 ou plus), offerte
dans la boutique d'extensions de VS Code (chercher « Simulateur Arduino Grove », éditeur
**ve2cuy**); à l'ouverture de l'espace de travail, VS Code propose de l'installer. Le
montage complet, avec les deux cartes, les 17 modules et le câble, est déjà décrit dans les
fichiers `montage.json` et `circuit.json`.

1. Dans VS Code : *Fichier → Ouvrir l'espace de travail à partir d'un fichier…*, puis choisir
   **`Station-Grove.code-workspace`**.
2. Compiler **les deux projets** : dans la barre de PlatformIO, choisir le projet
   *Poste de capteurs (UNO)* puis *Build* (✓), et la même chose pour *Centrale (MEGA)*.
   La première compilation télécharge les bibliothèques : elle prend une minute.
3. Le simulateur s'ouvre de lui-même (réglage de l'espace de travail); sinon, cliquer sur son
   icône en haut à droite de l'éditeur.
4. Les modules apparaissent autour de leur carte. S'ils se chevauchent, choisir **Ranger…** dans la
   barre du simulateur.
5. En bas, un onglet de moniteur série par carte. Taper **`?`** puis Entrée pour voir le menu.

Dans le simulateur :

- le **bouton** se tient enfoncé avec la souris;
- le **détecteur de mouvement** : cliquer sur son dessin;
- le **potentiomètre** : glisser son curseur;
- le **lecteur RFID** : le code `2E008BA5AEAE` est proposé; cliquer sur « Présenter ». Ce badge
  est autorisé (voir `BADGES_AUTORISES` dans `centrale-mega/include/config.h`). Changer un chiffre
  pour essayer un badge refusé;
- le **buzzer** : son bouton « 🔇 Son » le fait entendre dans les haut-parleurs;
- le **Wi-Fi** : le simulateur ouvre de vraies connexions Internet, et accepte n'importe quel nom
  de réseau et mot de passe;
- sur le **câble**, les octets échangés défilent en 0 et 1, avec une flèche qui montre leur sens.

---

## 4 – Démarrer sur le vrai matériel

1. Brancher les modules selon le tableau de la section 2, sur le hat Grove de chaque carte.
2. Relier la prise **D8 du UNO** à la prise **UART2 du MEGA** par un câble Grove.
3. Les deux cartes doivent avoir une **masse commune** : c'est le cas par le câble Grove (fil noir).
4. Téléverser chaque projet sur sa carte (*Upload*, →), en choisissant le bon port USB.
5. Ouvrir le moniteur série de chaque carte à **115200 bauds**.
6. Le Wi-Fi : mettre le nom et le mot de passe du réseau dans `WIFI_RESEAU` et
   `WIFI_MOT_DE_PASSE` (`centrale-mega/include/config.h`).
7. L'horloge RTC : au premier démarrage, taper **`h`** dans le moniteur du UNO pour la mettre à
   l'heure de la compilation. Sa pile la garde ensuite à l'heure.

---

## 5 – Les menus

Dans le moniteur série de chaque carte, taper une touche puis Entrée.

### Poste de capteurs (UNO)

| Touche | Action |
|---|---|
| `?` | Afficher le menu |
| `e` | État de tous les modules et dernières mesures |
| `1` | DEL verte : allumer / éteindre |
| `2` | Relais : fermer / ouvrir |
| `3` | Détecteur de mouvement : surveiller / ignorer |
| `4` | DEL rouge : suit le potentiomètre / éteinte |
| `5` | LCD RGB : rétroéclairage allumé / éteint |
| `6` | Envoi des mesures au MEGA : actif / suspendu |
| `h` | Régler l'horloge RTC à l'heure de la compilation |
| `m` | Envoyer un message de test au MEGA |

### Centrale (MEGA)

| Touche | Action |
|---|---|
| `?` | Afficher le menu |
| `e` | État de tous les modules, et données reçues du UNO |
| `1` | DEL bleue : témoin du lien actif / éteint |
| `2` | Afficheur 4-Digit : mode suivant (heure → potentiomètre → température → éteint) |
| `3` | Barre de DEL : mode suivant (niveau du potentiomètre → arc-en-ciel → éteinte) |
| `4` | Buzzer : actif / muet |
| `5` | Buzzer : jouer une mélodie d'essai |
| `6` | Relais **du UNO** : fermer / ouvrir (commande à distance) |
| `7` | DEL verte **du UNO** : allumer / éteindre (commande à distance) |
| `8` | LCD 20x4 : rétroéclairage allumé / éteint |
| `r` | Lecteur RFID : actif / ignoré |
| `u` | Demander au UNO toutes ses mesures |
| `v` | Afficher chaque message reçu du UNO : oui / non |
| `w` | Wi-Fi : se connecter et interroger `example.com` |

---

## 6 – Visite guidée : essayer chaque module

Suivre ces étapes dans l'ordre fait fonctionner les 17 modules et le lien.

1. **Le lien.** Au démarrage, la 4e ligne du LCD 20x4 indique « Lien UNO etabli », et la
   **DEL bleue** clignote à chaque message reçu (environ trois par seconde).
   Taper `v` dans le moniteur du MEGA pour **voir passer les messages** : `HEURE=14:05:09`,
   `TEMP=22.0`… Taper `v` de nouveau pour arrêter.
2. **L'horloge et les afficheurs.** L'heure de l'**horloge RTC** du UNO s'affiche sur le
   **LCD RGB**, sur le **LCD 20x4** et sur l'**afficheur 4-Digit** (le « : » clignote).
3. **Les capteurs.** La température et l'humidité du **SHT31**, puis la pression du **BME280**,
   alternent sur la 2e ligne du LCD RGB, et s'affichent sur le LCD 20x4. Dans le simulateur,
   changer la température d'un capteur et la voir arriver à la centrale au plus 2 s plus tard.
4. **Le potentiomètre.** Le tourner : la **DEL rouge** du UNO change d'intensité, la **barre de
   DEL** du MEGA se remplit du vert au rouge, le pourcentage s'affiche sur les deux LCD. Taper `2`
   sur le MEGA : l'afficheur 4-Digit montre maintenant le potentiomètre.
5. **Le bouton.** Appuyer : la **DEL verte** du UNO s'allume (ou s'éteint), le LCD RGB devient
   orange, le **buzzer** fait un bip, la barre de DEL passe à l'orange.
6. **Le détecteur de mouvement.** Déclencher un mouvement : le LCD RGB devient rouge, la centrale
   sonne l'alerte et la barre clignote en rouge pendant 3 s. Taper `3` sur le UNO pour ignorer
   les mouvements, et vérifier que l'alerte ne se déclenche plus.
7. **Le lecteur RFID.** Présenter le badge `2E008BA5AEAE` : « Accepte » sur le LCD 20x4, mélodie,
   barre verte, et le **relais** du UNO se ferme 3 s. Présenter un autre code : « Refuse ».
8. **Les commandes à distance.** Sur le MEGA, taper `6` (le relais du UNO change d'état) et `7`
   (sa DEL verte aussi). Le UNO affiche la commande reçue : `<- MEGA : RELAIS=1`.
9. **Le Wi-Fi.** Sur le MEGA, taper `w` : connexion au réseau, adresse IP, puis la réponse du site
   (« WiFi: HTTP 200 » si tout va bien).
10. **Activer et désactiver.** Essayer les autres touches des menus : barre en arc-en-ciel (`3`),
    buzzer muet (`4`), rétroéclairages (`5` sur le UNO, `8` sur le MEGA), mesures suspendues
    (`6` sur le UNO : après 5 s, la centrale annonce « Lien UNO perdu! », puisque l'heure n'arrive
    plus).

---

## 7 – Le protocole entre les deux cartes

Les cartes échangent des **messages texte**, un par ligne, de la forme `CLE=valeur` :

```
TEMP=22.0
HEURE=14:05:09
BADGE=OK
```

Le fichier `include/protocole.h` définit toutes les clés. Il existe en **deux exemplaires
identiques**, un par projet : les deux cartes doivent parler le même langage.

### Du UNO vers le MEGA

| Message | Exemple | Quand |
|---|---|---|
| `TEMP` | `TEMP=22.0` | toutes les 2 s (SHT31, °C) |
| `HUM` | `HUM=45` | toutes les 2 s (SHT31, %) |
| `TBME` | `TBME=21.8` | toutes les 2 s (BME280, °C) |
| `PRES` | `PRES=1013.2` | toutes les 2 s (BME280, hPa) |
| `HEURE` | `HEURE=14:05:09` | chaque seconde (horloge RTC) |
| `POT` | `POT=50` | quand le potentiomètre bouge d'au moins 2 % |
| `BOUTON` | `BOUTON=3` | à chaque appui (nombre d'appuis) |
| `MOUV` | `MOUV=1` | au début d'un mouvement |
| `RELAIS` | `RELAIS=1` | quand le relais change (1 = fermé) |
| `VERTE` | `VERTE=0` | quand la DEL verte change |
| `BONJOUR` | `BONJOUR=UNO` | au démarrage du UNO, ou touche `m` |

### Du MEGA vers le UNO

| Message | Exemple | Effet sur le UNO |
|---|---|---|
| `RELAIS` | `RELAIS=1` | ferme (1) ou ouvre (0) le relais |
| `VERTE` | `VERTE=1` | allume (1) ou éteint (0) la DEL verte |
| `BADGE` | `BADGE=OK` ou `BADGE=REFUSE` | ouvre la « porte » 3 s, ou affiche le refus |
| `ETAT` | `ETAT=?` | renvoie toutes ses mesures |

### Pourquoi du texte?

- On peut **lire** les messages : dans le moniteur série (`v`), à l'oscilloscope du simulateur
  (décodage UART sur les broches du câble), ou dans l'animation des bits.
- Un message abîmé ou inconnu est **ignoré**, sans décaler les suivants : la fin de ligne remet
  les deux cartes d'accord.
- On **ajoute** un message sans rien casser : une clé inconnue est simplement ignorée.

Le prix : un nombre prend plus d'octets qu'en binaire. À 9600 bauds (environ 960 octets par
seconde) et une vingtaine de messages par seconde au plus, c'est sans importance.

### Le câble

| | UNO | MEGA |
|---|---|---|
| Prise | D8 | UART2 |
| Port série | `SoftwareSerial lienMega(9, 8)` (RX = D9, TX = D8) | `Serial2` (RX2 = 17, TX2 = 16) |
| Vitesse | 9600 bauds | 9600 bauds |

Le UNO n'a qu'un seul port série matériel (`Serial`), déjà pris par le câble USB et le moniteur :
il utilise **SoftwareSerial**, qui fait un port série avec deux broches ordinaires. Le MEGA, lui,
a **quatre** ports matériels : `Serial`, `Serial1` (Wi-Fi), `Serial2` (UNO) et `Serial3` (RFID).

---

## 8 – Comment le code est organisé

### Des tâches, pas de `delay()`

`loop()` appelle à tour de rôle de petites **tâches**, une par module ou presque :

```cpp
void loop() {
  tacheMenu();          // une touche du moniteur?
  tacheLienMega();      // un message du MEGA?
  tacheBouton();        // le bouton vient-il d'être enfoncé?
  tacheMouvement();
  tachePotentiometre(); // toutes les 100 ms
  tacheCapteurs();      // toutes les 2 s
  tacheHorloge();       // chaque seconde
  tachePorte();         // fin de l'ouverture par badge?
  tacheLcd();           // toutes les 500 ms
}
```

Chaque tâche fait **très peu** de travail et rend la main. `loop()` tourne ainsi des milliers de
fois par seconde : le bouton reste réactif pendant que les capteurs sont lus, et aucun message
n'attend. Avec un `delay(2000)` pour lire les capteurs, le bouton serait sourd pendant 2 s!

Une tâche périodique utilise la fonction `estMomentDe()` :

```cpp
void tacheCapteurs() {
  static unsigned long dernierPassage = 0;           // garde sa valeur d'un appel à l'autre
  if (!estMomentDe(dernierPassage, DELAI_CAPTEURS)) {
    return;                                          // pas encore le moment : on rend la main
  }
  // ... lire les capteurs, envoyer les mesures
}
```

### Recevoir un message sans attendre

`lireMessage()` accumule les caractères **déjà arrivés** dans un tampon, et retourne `true`
seulement quand une fin de ligne complète le message. Si le message n'est pas complet, elle
retourne `false` tout de suite : on y reviendra au prochain tour de `loop()`.

Le message complet est découpé à la main : `strchr()` trouve le `=`, qu'on remplace par une fin
de chaîne; on obtient deux chaînes, la clé et la valeur, comparées avec `strcmp()`.

### Détecter un front

Le bouton et le détecteur de mouvement réagissent au **changement** (LOW → HIGH), pas à l'état :
on garde la lecture précédente, et on agit seulement quand elle passe de LOW à HIGH. Le bouton a
en plus un **anti-rebond** : un vrai contact « rebondit » plusieurs fois en quelques
millisecondes, et on attend que la lecture soit stable 30 ms avant d'y croire.

### Des mélodies qui ne bloquent pas

Sur le MEGA, une mélodie est un tableau de notes (fréquence, durée). `jouer()` la lance;
`tacheBuzzer()` passe à la note suivante quand la précédente est finie. Pendant ce temps, tout le
reste continue.

---

## 9 – Pièges et leçons apprises

Ces problèmes sont **réellement survenus** pendant l'écriture du projet. Les solutions sont dans le code.

**Des messages perdus pendant que la centrale écrit sur son LCD.** Un port série garde les octets
reçus dans un **tampon** de 64 octets, en attendant que le programme les lise. Réécrire les 80
caractères du LCD 20x4 par I2C occupe le MEGA plus d'un dixième de seconde : assez pour que plus
de 64 octets arrivent du UNO, et que le tampon déborde. Résultat observé : `POT=TEMP=22.0`, deux
messages coupés et collés. Deux corrections :

- `ecrireLigneLcd()` ne réécrit une ligne **que si elle a changé**;
- le tampon des ports série du MEGA passe à 256 octets, par la ligne
  `build_flags = -D SERIAL_RX_BUFFER_SIZE=256` de `platformio.ini`.

**Le moniteur série ralentit tout.** `Serial.print()` attend quand son propre tampon d'envoi est
plein. À 9600 bauds, afficher l'état complet (900 caractères) prend près d'une seconde, pendant
laquelle la carte ne fait rien d'autre. Les moniteurs sont donc à **115200 bauds**, douze fois plus
vite. Les textes du menu sont entre `F("...")` : ils restent dans la mémoire flash au lieu
d'occuper la RAM (le UNO n'a que 2 Ko de RAM).

**`tone()` et `analogWrite()`.** `tone()` utilise le Timer2 du microcontrôleur; sur le UNO, ce même
timer fait le PWM des broches 3 et 11. C'est une raison de mettre le buzzer sur le MEGA, et la DEL
rouge (en PWM sur D3) sur le UNO.

**SoftwareSerial a ses limites.** Il ne peut écouter qu'un seul port à la fois, et il bloque les
interruptions pendant qu'il envoie un octet. À 9600 bauds, c'est sans conséquence ici.

**`snprintf()` ne sait pas écrire un nombre à virgule** sur un Arduino (`%f` donne `?`). On utilise
`dtostrf()`, dans la fonction `nombreEnTexte()`.

**L'afficheur 4-Digit et les zéros.** `displayNum()` de la bibliothèque laisse les zéros de tête
éteints : 00:05 s'afficherait «   :05 », et 0 ne s'afficherait pas du tout. Le programme écrit donc
chaque chiffre lui-même, avec `display(position, chiffre)`.

---

## 10 – Pour aller plus loin

Quelques idées d'exercices, de la plus simple à la plus exigeante :

1. Ajouter un badge autorisé dans `BADGES_AUTORISES`.
2. Changer les couleurs du LCD RGB (`COULEUR_…` dans `poste-uno/include/config.h`).
3. Composer une nouvelle mélodie pour le badge accepté.
4. Ajouter un mode à l'afficheur 4-Digit : l'humidité, ou le nombre d'appuis sur le bouton.
5. Ajouter un message au protocole : par exemple `SEUIL=28`, envoyé par le MEGA, au-dessus duquel le
   UNO ferme son relais (un ventilateur!). Ne pas oublier de copier `protocole.h` dans les deux projets.
6. Envoyer les mesures à une API Web par le Wi-Fi, avec une requête `POST`.
7. Enregistrer les badges présentés, avec leur heure, dans l'EEPROM du MEGA.
8. Faire vérifier chaque message par une somme de contrôle (par exemple `TEMP=22.0*5A`).

---

## 11 – Les fichiers du projet

```
420-1C4-Station-Grove-UART/
├── README.md                       ce document
├── Station-Grove.code-workspace    l'espace de travail VS Code (les deux projets)
├── montage.json                    le montage du simulateur : les deux cartes et le câble
├── poste-uno/                      le projet PlatformIO du UNO
│   ├── platformio.ini              carte, vitesse du moniteur, bibliothèques
│   ├── circuit.json                les modules du UNO, pour le simulateur
│   ├── include/config.h            broches, délais, seuils, couleurs
│   ├── include/protocole.h         les messages entre les cartes (copie identique)
│   └── src/main.cpp                le programme
└── centrale-mega/                  le projet PlatformIO du MEGA
    ├── platformio.ini
    ├── circuit.json
    ├── include/config.h            broches, ports série, Wi-Fi, badges autorisés
    ├── include/protocole.h         (copie identique)
    ├── lib/4Digit/                 la bibliothèque TM1637V2 de l'afficheur 4-Digit
    └── src/main.cpp
```
