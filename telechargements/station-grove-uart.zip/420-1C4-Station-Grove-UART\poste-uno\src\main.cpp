/*
 * =====================================================================
 *  Station Grove à deux Arduino — LE POSTE DE CAPTEURS (carte UNO)
 * ---------------------------------------------------------------------
 *  Cours 420-1C4 — Objets connectés                         Par VE2CUY
 *  Version 1.0 — 2026-11-20
 * =====================================================================
 *
 *  Rôle de cette carte
 *  -------------------
 *  Le UNO est le « poste » installé sur le terrain. Il MESURE (température,
 *  humidité, pression, heure, potentiomètre, bouton, mouvement), il AGIT sur
 *  place (relais, DEL rouge et verte, LCD RGB) et il ENVOIE tout au MEGA, la
 *  centrale, par un câble UART. Il obéit aussi aux commandes de la centrale :
 *  fermer le relais, allumer la DEL verte, ouvrir la « porte » quand un badge
 *  RFID est accepté.
 *
 *  Les modules de cette carte (voir config.h pour les broches)
 *  ----------------------------------------------------------
 *    Bouton, DEL rouge, relais, détecteur de mouvement, DEL verte,
 *    potentiomètre, LCD RGB, capteur SHT31, capteur BME280, horloge DS1307.
 *
 *  Comment le programme est organisé
 *  ---------------------------------
 *  loop() appelle à tour de rôle une série de petites TÂCHES. Chacune fait
 *  très peu de travail puis rend la main : aucune n'utilise delay(). Une
 *  tâche qui doit agir « toutes les 2 secondes » regarde l'heure avec
 *  millis() et ne fait rien tant que son moment n'est pas venu (voir la
 *  fonction estMomentDe()). Ainsi, le bouton reste réactif pendant que les
 *  capteurs sont lus, et aucun message du MEGA n'est perdu.
 *
 *  Le menu (moniteur série, 115200 bauds)
 *  ------------------------------------
 *  Taper une touche puis Entrée. « ? » affiche le menu complet.
 *
 *  Le protocole avec le MEGA est décrit dans protocole.h.
 */

#include <Arduino.h>
#include <Wire.h>              // le bus I2C, partagé par le LCD, les capteurs et l'horloge
#include <SoftwareSerial.h>    // un port série « logiciel », sur deux broches ordinaires
#include "rgb_lcd.h"           // Grove - LCD RGB Backlight
#include "SHT31.h"             // Grove - SHT31 (température et humidité)
#include "Seeed_BME280.h"      // Grove - BME280 (température, humidité, pression)
#include "DS1307.h"            // Grove - RTC DS1307 (horloge en temps réel)
#include "config.h"
#include "protocole.h"

// =====================================================================
//  Les objets qui représentent les modules
// =====================================================================

SoftwareSerial lienMega(BROCHE_LIEN_RX, BROCHE_LIEN_TX);   // RX, TX : le câble vers le MEGA
rgb_lcd lcd;
SHT31 capteurSht31 = SHT31();
BME280 capteurBme280;
DS1307 horloge;

// =====================================================================
//  L'état du poste
// =====================================================================

// --- Ce que l'utilisateur active ou désactive au menu ---
bool delVerteAllumee     = false;   // la DEL verte (menu 1, bouton, ou commande du MEGA)
bool relaisFerme         = false;   // le relais (menu 2 ou commande du MEGA)
bool mouvementSurveille  = true;    // le détecteur de mouvement déclenche-t-il une alerte? (menu 3)
bool delRougeSuitPot     = true;    // la DEL rouge suit-elle le potentiomètre? (menu 4)
bool retroEclairage      = true;    // le rétroéclairage du LCD RGB (menu 5)
bool envoiMesures        = true;    // envoyer les mesures au MEGA? (menu 6)

// --- Les dernières mesures ---
float temperatureSht31   = NAN;     // NAN (« pas un nombre ») tant qu'aucune mesure n'est faite
float humiditeSht31      = NAN;
float temperatureBme280  = NAN;
float pressionHpa        = NAN;
bool  bme280Present      = false;   // init() du BME280 a-t-il trouvé le capteur?
int   potentiometrePct   = -1;      // 0 à 100 %; -1 : pas encore lu
int   potentiometreEnvoye = -100;   // dernière valeur envoyée au MEGA
char  heure[9]           = "--:--:--";   // HH:MM:SS, et le 0 de fin de chaîne
unsigned int nbAppuis    = 0;       // nombre d'appuis sur le bouton depuis le démarrage

// --- Les événements en cours (0 = aucun) ---
unsigned long finMessageLcd   = 0;  // jusqu'à quand le LCD montre un message d'événement
unsigned long finOuverture    = 0;  // jusqu'à quand le relais reste fermé après un badge accepté
char messageLcd[LCD_COLONNES + 1] = "";

// =====================================================================
//  Outils
// =====================================================================

/**
 * Vrai quand une tâche doit agir : au moins `delai` millisecondes se sont
 * écoulées depuis son dernier passage, noté dans `dernierPassage`.
 *
 * `dernierPassage` est passé PAR RÉFÉRENCE (le &) : la fonction modifie la
 * variable de l'appelant. Chaque tâche a la sienne, déclarée `static` pour
 * qu'elle garde sa valeur d'un appel à l'autre.
 *
 * La soustraction millis() - dernierPassage reste juste même quand millis()
 * repart à zéro, après 49 jours : c'est la bonne façon de comparer des temps.
 */
bool estMomentDe(unsigned long &dernierPassage, unsigned long delai) {
  unsigned long maintenant = millis();
  if (maintenant - dernierPassage >= delai) {
    dernierPassage = maintenant;
    return true;
  }
  return false;
}

/** Écrit un nombre à virgule dans une chaîne. snprintf() ne sait pas le faire sur un Arduino. */
void nombreEnTexte(float valeur, byte decimales, char *texte) {
  if (isnan(valeur)) {
    strcpy(texte, "--");
  } else {
    dtostrf(valeur, 1, decimales, texte);   // largeur minimale 1 : pas d'espaces devant
  }
}

// =====================================================================
//  Le lien avec le MEGA : envoyer et recevoir des messages
// =====================================================================

/** Envoie un message texte : « cle=valeur » suivi d'une fin de ligne. */
void envoyer(const char *cle, const char *valeur) {
  lienMega.print(cle);
  lienMega.print(SEPARATEUR);
  lienMega.println(valeur);   // println ajoute \r\n : la fin du message
}

/** La même chose pour un nombre entier. */
void envoyer(const char *cle, long valeur) {
  char texte[12];
  ltoa(valeur, texte, 10);
  envoyer(cle, texte);
}

/** La même chose pour un nombre à virgule, avec `decimales` chiffres après la virgule. */
void envoyer(const char *cle, float valeur, byte decimales) {
  if (isnan(valeur)) {
    return;   // pas de mesure valide : on n'envoie rien plutôt qu'un nombre faux
  }
  char texte[16];
  nombreEnTexte(valeur, decimales, texte);
  envoyer(cle, texte);
}

/**
 * Accumule les caractères reçus du MEGA jusqu'à une fin de ligne. Retourne
 * vrai quand un message complet est dans `message`.
 *
 * On ne lit que les caractères DÉJÀ arrivés : si le message n'est pas
 * complet, la fonction retourne faux et on y reviendra au prochain tour de
 * loop(). Rien n'attend, rien ne bloque.
 */
bool lireMessage(char *message) {
  static char tampon[LONGUEUR_MAX_MESSAGE + 1];
  static byte longueur = 0;

  while (lienMega.available() > 0) {
    char c = lienMega.read();
    if (c == '\r') {
      continue;                       // on ignore le retour de chariot
    }
    if (c == '\n') {                  // fin de ligne : le message est complet
      tampon[longueur] = '\0';
      strcpy(message, tampon);
      longueur = 0;
      return true;
    }
    if (longueur < LONGUEUR_MAX_MESSAGE) {
      tampon[longueur++] = c;         // trop long? les caractères en trop sont perdus
    }
  }
  return false;
}

/** Affiche un message d'événement sur le LCD, dans une couleur, pendant DUREE_MESSAGE_LCD. */
void afficherEvenement(const char *texte, byte rouge, byte vert, byte bleu) {
  strncpy(messageLcd, texte, LCD_COLONNES);
  messageLcd[LCD_COLONNES] = '\0';
  finMessageLcd = millis() + DUREE_MESSAGE_LCD;
  if (retroEclairage) {
    lcd.setRGB(rouge, vert, bleu);
  }
}

// =====================================================================
//  Les actions (appelées par le menu, par le bouton ou par le MEGA)
// =====================================================================

void reglerDelVerte(bool allumee) {
  delVerteAllumee = allumee;
  digitalWrite(BROCHE_DEL_VERTE, allumee ? HIGH : LOW);
  envoyer(MSG_ETAT_VERTE, (long)allumee);   // le MEGA garde l'état à jour
}

void reglerRelais(bool ferme) {
  relaisFerme = ferme;
  digitalWrite(BROCHE_RELAIS, ferme ? HIGH : LOW);
  envoyer(MSG_ETAT_RELAIS, (long)ferme);
}

/** Envoie toutes les mesures connues au MEGA (au démarrage, et quand il le demande). */
void envoyerTout() {
  envoyer(MSG_HEURE, heure);
  envoyer(MSG_TEMPERATURE, temperatureSht31, 1);
  envoyer(MSG_HUMIDITE, humiditeSht31, 0);
  envoyer(MSG_TEMP_BME, temperatureBme280, 1);
  envoyer(MSG_PRESSION, pressionHpa, 1);
  if (potentiometrePct >= 0) {
    envoyer(MSG_POTENTIOMETRE, (long)potentiometrePct);
  }
  envoyer(MSG_ETAT_RELAIS, (long)relaisFerme);
  envoyer(MSG_ETAT_VERTE, (long)delVerteAllumee);
}

/**
 * Met l'horloge RTC à l'heure où le programme a été COMPILÉ. Le compilateur
 * fournit deux textes : __DATE__ (« Nov 20 2026 ») et __TIME__ (« 14:05:09 »).
 * L'horloge DS1307 a sa propre pile : elle garde ensuite l'heure, même
 * Arduino éteint.
 */
void reglerHorlogeALaCompilation() {
  const char *mois = "JanFebMarAprMayJunJulAugSepOctNovDec";
  char nomMois[4] = { __DATE__[0], __DATE__[1], __DATE__[2], '\0' };
  int numeroMois = (strstr(mois, nomMois) - mois) / 3 + 1;   // position dans la liste, de 1 à 12
  int jour  = atoi(__DATE__ + 4);
  int annee = atoi(__DATE__ + 7);

  // Le jour de la semaine (1 = lundi ... 7 = dimanche), par la méthode de Sakamoto.
  static const int decalages[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
  int a = annee - (numeroMois < 3 ? 1 : 0);
  int jourSemaine = (a + a / 4 - a / 100 + a / 400 + decalages[numeroMois - 1] + jour) % 7;   // 0 = dimanche

  horloge.fillByYMD(annee, numeroMois, jour);
  horloge.fillByHMS(atoi(__TIME__), atoi(__TIME__ + 3), atoi(__TIME__ + 6));
  horloge.fillDayOfWeek(jourSemaine == 0 ? 7 : jourSemaine);
  horloge.setTime();

  Serial.print(F("Horloge reglee a : "));
  Serial.print(__DATE__);
  Serial.print(' ');
  Serial.println(__TIME__);
}

// =====================================================================
//  Le menu du moniteur série
// =====================================================================

void afficherMenu() {
  Serial.println();
  Serial.println(F("=========== POSTE DE CAPTEURS (UNO) ==========="));
  Serial.println(F("  ?  Ce menu"));
  Serial.println(F("  e  Etat de tous les modules et dernieres mesures"));
  Serial.println(F("  1  DEL verte (D7) : allumer / eteindre"));
  Serial.println(F("  2  Relais (D4) : fermer / ouvrir"));
  Serial.println(F("  3  Detecteur de mouvement (D5) : surveiller / ignorer"));
  Serial.println(F("  4  DEL rouge (D3) : suit le potentiometre / eteinte"));
  Serial.println(F("  5  LCD RGB : retroeclairage allume / eteint"));
  Serial.println(F("  6  Envoi des mesures au MEGA : actif / suspendu"));
  Serial.println(F("  h  Regler l'horloge RTC a l'heure de la compilation"));
  Serial.println(F("  m  Envoyer un message de test au MEGA"));
  Serial.println(F("  Le bouton (D2) allume ou eteint la DEL verte."));
  Serial.println(F("==============================================="));
}

/** Affiche « nom : OUI » ou « nom : non », bien aligné. */
void afficherEtatModule(const __FlashStringHelper *nom, bool actif) {
  Serial.print(nom);
  Serial.println(actif ? F("OUI") : F("non"));
}

void afficherEtat() {
  char texte[12];
  Serial.println();
  Serial.println(F("--- Etat du poste ---"));
  afficherEtatModule(F("DEL verte allumee .......... "), delVerteAllumee);
  afficherEtatModule(F("Relais ferme ............... "), relaisFerme);
  afficherEtatModule(F("Mouvement surveille ........ "), mouvementSurveille);
  afficherEtatModule(F("DEL rouge suit le pot. ..... "), delRougeSuitPot);
  afficherEtatModule(F("Retroeclairage du LCD ...... "), retroEclairage);
  afficherEtatModule(F("Envoi des mesures au MEGA .. "), envoiMesures);
  afficherEtatModule(F("Capteur BME280 present ..... "), bme280Present);
  Serial.print(F("Heure (RTC) ................ ")); Serial.println(heure);
  nombreEnTexte(temperatureSht31, 1, texte);
  Serial.print(F("Temperature SHT31 .......... ")); Serial.print(texte); Serial.println(F(" C"));
  nombreEnTexte(humiditeSht31, 0, texte);
  Serial.print(F("Humidite SHT31 ............. ")); Serial.print(texte); Serial.println(F(" %"));
  nombreEnTexte(temperatureBme280, 1, texte);
  Serial.print(F("Temperature BME280 ......... ")); Serial.print(texte); Serial.println(F(" C"));
  nombreEnTexte(pressionHpa, 1, texte);
  Serial.print(F("Pression BME280 ............ ")); Serial.print(texte); Serial.println(F(" hPa"));
  Serial.print(F("Potentiometre .............. ")); Serial.print(potentiometrePct); Serial.println(F(" %"));
  Serial.print(F("Appuis sur le bouton ....... ")); Serial.println(nbAppuis);
}

/** TÂCHE : lit une touche du moniteur série, s'il y en a une, et l'exécute. */
void tacheMenu() {
  if (Serial.available() == 0) {
    return;
  }
  char touche = Serial.read();
  switch (touche) {
    case '?': afficherMenu(); break;
    case 'e': afficherEtat(); break;
    case '1':
      reglerDelVerte(!delVerteAllumee);
      afficherEtatModule(F("DEL verte allumee : "), delVerteAllumee);
      break;
    case '2':
      reglerRelais(!relaisFerme);
      afficherEtatModule(F("Relais ferme : "), relaisFerme);
      break;
    case '3':
      mouvementSurveille = !mouvementSurveille;
      afficherEtatModule(F("Mouvement surveille : "), mouvementSurveille);
      break;
    case '4':
      delRougeSuitPot = !delRougeSuitPot;
      if (!delRougeSuitPot) {
        analogWrite(BROCHE_DEL_ROUGE, 0);
      }
      afficherEtatModule(F("DEL rouge suit le potentiometre : "), delRougeSuitPot);
      break;
    case '5':
      retroEclairage = !retroEclairage;
      if (retroEclairage) {
        lcd.setRGB(COULEUR_NORMALE);
      } else {
        lcd.setRGB(0, 0, 0);
      }
      afficherEtatModule(F("Retroeclairage : "), retroEclairage);
      break;
    case '6':
      envoiMesures = !envoiMesures;
      afficherEtatModule(F("Envoi des mesures au MEGA : "), envoiMesures);
      break;
    case 'h': reglerHorlogeALaCompilation(); break;
    case 'm':
      envoyer(MSG_BONJOUR, "TEST");
      Serial.println(F("Message BONJOUR=TEST envoye au MEGA"));
      break;
    default:
      break;   // Entrée, espace, touche inconnue : on ignore
  }
}

// =====================================================================
//  Les tâches des modules
// =====================================================================

/** TÂCHE : traite les messages reçus du MEGA. */
void tacheLienMega() {
  char message[LONGUEUR_MAX_MESSAGE + 1];
  if (!lireMessage(message)) {
    return;
  }

  // Découper « CLE=valeur » : on remplace le = par une fin de chaîne.
  char *separateur = strchr(message, SEPARATEUR);
  if (separateur == NULL) {
    return;                           // pas de = : message invalide, ignoré
  }
  *separateur = '\0';
  const char *cle = message;
  const char *valeur = separateur + 1;

  Serial.print(F("<- MEGA : "));
  Serial.print(cle);
  Serial.print('=');
  Serial.println(valeur);

  if (strcmp(cle, CMD_RELAIS) == 0) {
    reglerRelais(atoi(valeur) == 1);
  } else if (strcmp(cle, CMD_VERTE) == 0) {
    reglerDelVerte(atoi(valeur) == 1);
  } else if (strcmp(cle, CMD_ETAT) == 0) {
    envoyerTout();
  } else if (strcmp(cle, CMD_BADGE) == 0) {
    if (strcmp(valeur, BADGE_ACCEPTE) == 0) {
      // Badge accepté : la « porte » s'ouvre. Le relais commanderait une gâche électrique.
      reglerRelais(true);
      finOuverture = millis() + DUREE_OUVERTURE_PORTE;
      afficherEvenement("Acces accorde", COULEUR_ACCES);
    } else {
      afficherEvenement("Acces refuse", COULEUR_ALERTE);
    }
  }
}

/**
 * TÂCHE : surveille le bouton. Un appui est compté au moment où le bouton
 * est ENFONCÉ (passage de LOW à HIGH), une seule fois même si on le tient.
 * L'anti-rebond ignore les changements plus courts que DELAI_ANTI_REBOND :
 * un vrai contact « rebondit » plusieurs fois en quelques millisecondes.
 */
void tacheBouton() {
  static bool etatStable = LOW;           // l'état retenu du bouton
  static bool derniereLecture = LOW;      // la lecture précédente, peut-être un rebond
  static unsigned long depuis = 0;        // depuis quand la lecture n'a pas changé

  bool lecture = digitalRead(BROCHE_BOUTON);
  if (lecture != derniereLecture) {
    derniereLecture = lecture;
    depuis = millis();
    return;
  }
  if (lecture != etatStable && millis() - depuis >= DELAI_ANTI_REBOND) {
    etatStable = lecture;
    if (etatStable == HIGH) {             // le bouton Grove donne HIGH quand il est enfoncé
      nbAppuis++;
      reglerDelVerte(!delVerteAllumee);
      envoyer(MSG_BOUTON, (long)nbAppuis);
      afficherEvenement("Bouton appuye", COULEUR_BOUTON);
      Serial.print(F("Bouton appuye ("));
      Serial.print(nbAppuis);
      Serial.println(F(")"));
    }
  }
}

/**
 * TÂCHE : surveille le détecteur de mouvement. Le détecteur Grove met sa
 * sortie à HIGH quand il voit un mouvement, et la garde ainsi quelques
 * secondes. On réagit seulement au DÉBUT (passage de LOW à HIGH).
 */
void tacheMouvement() {
  static bool avant = LOW;
  bool maintenant = digitalRead(BROCHE_MOUVEMENT);
  if (maintenant == HIGH && avant == LOW && mouvementSurveille) {
    envoyer(MSG_MOUVEMENT, 1L);
    afficherEvenement("MOUVEMENT!", COULEUR_ALERTE);
    Serial.println(F("Mouvement detecte"));
  }
  avant = maintenant;
}

/**
 * TÂCHE : lit le potentiomètre. analogRead() donne 0 à 1023 (0 V à 5 V);
 * map() le convertit en pourcentage. La DEL rouge suit le potentiomètre :
 * analogWrite() règle son intensité de 0 à 255 par PWM (la broche est
 * allumée une fraction du temps, assez vite pour que l'œil voie une lumière
 * plus ou moins forte).
 */
void tachePotentiometre() {
  static unsigned long dernierPassage = 0;
  if (!estMomentDe(dernierPassage, DELAI_POTENTIOMETRE)) {
    return;
  }
  int brut = analogRead(BROCHE_POTENTIOMETRE);
  potentiometrePct = map(brut, 0, 1023, 0, 100);
  if (delRougeSuitPot) {
    analogWrite(BROCHE_DEL_ROUGE, map(brut, 0, 1023, 0, 255));
  }
  // On n'envoie que les vrais changements : abs() est l'écart sans le signe.
  if (envoiMesures && abs(potentiometrePct - potentiometreEnvoye) >= ECART_POTENTIOMETRE) {
    potentiometreEnvoye = potentiometrePct;
    envoyer(MSG_POTENTIOMETRE, (long)potentiometrePct);
  }
}

/** TÂCHE : lit le SHT31 et le BME280, puis envoie les mesures au MEGA. */
void tacheCapteurs() {
  static unsigned long dernierPassage = 0;
  if (!estMomentDe(dernierPassage, DELAI_CAPTEURS)) {
    return;
  }
  temperatureSht31 = capteurSht31.getTemperature();
  humiditeSht31 = capteurSht31.getHumidity();
  if (bme280Present) {
    temperatureBme280 = capteurBme280.getTemperature();
    pressionHpa = capteurBme280.getPressure() / 100.0;   // le capteur donne des pascals; 1 hPa = 100 Pa
  }
  if (envoiMesures) {
    envoyer(MSG_TEMPERATURE, temperatureSht31, 1);
    envoyer(MSG_HUMIDITE, humiditeSht31, 0);
    envoyer(MSG_TEMP_BME, temperatureBme280, 1);
    envoyer(MSG_PRESSION, pressionHpa, 1);
  }
}

/** TÂCHE : lit l'heure de l'horloge RTC, une fois par seconde, et l'envoie au MEGA. */
void tacheHorloge() {
  static unsigned long dernierPassage = 0;
  if (!estMomentDe(dernierPassage, DELAI_HORLOGE)) {
    return;
  }
  horloge.getTime();   // lit l'heure dans la puce; elle est ensuite dans horloge.hour, .minute, .second
  snprintf(heure, sizeof(heure), "%02d:%02d:%02d", horloge.hour, horloge.minute, horloge.second);
  if (envoiMesures) {
    envoyer(MSG_HEURE, heure);
  }
}

/** TÂCHE : referme le relais à la fin d'une ouverture par badge. */
void tachePorte() {
  if (finOuverture != 0 && (long)(millis() - finOuverture) >= 0) {
    finOuverture = 0;
    reglerRelais(false);
  }
}

/**
 * TÂCHE : rafraîchit le LCD RGB.
 *   Ligne 1 : l'heure et le potentiomètre      14:05:09 Pot 50%
 *   Ligne 2 : en alternance, la température et l'humidité, puis la pression;
 *             ou le message d'un événement récent (bouton, mouvement, badge).
 * On réécrit toujours les 16 colonnes : les espaces effacent les restes
 * d'un texte plus long, sans appeler lcd.clear() qui fait clignoter l'écran.
 */
void tacheLcd() {
  static unsigned long dernierPassage = 0;
  static unsigned long dernierePage = 0;
  static byte page = 0;
  if (!estMomentDe(dernierPassage, DELAI_LCD)) {
    return;
  }

  char ligne[LCD_COLONNES + 1];
  snprintf(ligne, sizeof(ligne), "%s Pot%3d%%", heure, potentiometrePct < 0 ? 0 : potentiometrePct);
  lcd.setCursor(0, 0);
  lcd.print(ligne);

  char a[8], b[8];
  if (finMessageLcd != 0 && (long)(millis() - finMessageLcd) < 0) {
    snprintf(ligne, sizeof(ligne), "%-16s", messageLcd);   // %-16s : aligné à gauche, complété d'espaces
  } else {
    if (finMessageLcd != 0) {
      finMessageLcd = 0;                                    // fin de l'événement : retour à la couleur normale
      if (retroEclairage) {
        lcd.setRGB(COULEUR_NORMALE);
      }
    }
    if (estMomentDe(dernierePage, DELAI_PAGE_LCD)) {
      page = (page + 1) % 2;
    }
    if (page == 0) {
      nombreEnTexte(temperatureSht31, 1, a);
      nombreEnTexte(humiditeSht31, 0, b);
      snprintf(ligne, sizeof(ligne), "T %sC H %s%%        ", a, b);
    } else {
      nombreEnTexte(pressionHpa, 1, a);
      snprintf(ligne, sizeof(ligne), "P %s hPa        ", a);
    }
  }
  ligne[LCD_COLONNES] = '\0';
  lcd.setCursor(0, 1);
  lcd.print(ligne);
}

// =====================================================================
//  setup() et loop()
// =====================================================================

void setup() {
  Serial.begin(VITESSE_MONITEUR);
  lienMega.begin(VITESSE_LIEN);

  pinMode(BROCHE_BOUTON, INPUT);
  pinMode(BROCHE_MOUVEMENT, INPUT);
  pinMode(BROCHE_RELAIS, OUTPUT);
  pinMode(BROCHE_DEL_VERTE, OUTPUT);
  pinMode(BROCHE_DEL_ROUGE, OUTPUT);

  // Les modules I2C. L'ordre n'a pas d'importance : chacun répond à sa propre adresse
  // (LCD 0x3E et 0x62, SHT31 0x44, BME280 0x76 ou 0x77, horloge 0x68).
  lcd.begin(LCD_COLONNES, LCD_LIGNES);
  lcd.setRGB(COULEUR_NORMALE);
  lcd.print(F("Poste capteurs"));
  lcd.setCursor(0, 1);
  lcd.print(F("Par VE2CUY"));
  capteurSht31.begin();
  bme280Present = capteurBme280.init();
  horloge.begin();

  afficherMenu();
  if (!bme280Present) {
    Serial.println(F("Attention : capteur BME280 absent"));
  }

  envoyer(MSG_BONJOUR, "UNO");   // le MEGA saura que le poste vient de démarrer
  reglerRelais(false);
  reglerDelVerte(false);
}

void loop() {
  // Chaque tâche fait peu de travail et rend la main : loop() tourne des
  // milliers de fois par seconde, et chaque module reste réactif.
  tacheMenu();
  tacheLienMega();
  tacheBouton();
  tacheMouvement();
  tachePotentiometre();
  tacheCapteurs();
  tacheHorloge();
  tachePorte();
  tacheLcd();
}
