/*
 * =====================================================================
 *  config.h — Réglages du poste de capteurs (carte UNO)
 * ---------------------------------------------------------------------
 *  Cours 420-1C4 — Objets connectés                         Par VE2CUY
 *
 *  Tout ce qu'on peut vouloir changer est ici : les broches, les délais,
 *  les seuils et les couleurs. Le code de main.cpp n'utilise que ces noms :
 *  pour déplacer un module, on change UNE ligne, ici.
 * =====================================================================
 *
 *  Branchements sur le hat Grove « Base Shield V2 » du UNO
 *  ------------------------------------------------------
 *    Prise   Module                    Broche(s) utilisée(s)
 *    D2      Bouton                    D2
 *    D3      DEL rouge                 D3  (sortie PWM : intensité variable)
 *    D4      Relais                    D4
 *    D5      Détecteur de mouvement    D5
 *    D7      DEL verte                 D7
 *    D8      Câble vers le MEGA        D8 (TX) et D9 (RX), par SoftwareSerial
 *    A0      Potentiomètre             A0
 *    I2C     LCD RGB, SHT31, BME280,   SDA (A4) et SCL (A5), partagées :
 *            horloge RTC DS1307        chaque module a sa propre adresse
 *
 *  Une prise Grove porte DEUX broches : la prise D2 donne accès à D2 et à D3.
 *  Un module simple n'utilise que la première; c'est pourquoi la prise D3
 *  reste libre pour la DEL rouge. Le câble vers le MEGA, lui, utilise les
 *  deux broches de la prise D8 (TX sur D8, RX sur D9).
 */

#ifndef CONFIG_H
#define CONFIG_H

// ------------------------------------------------------------------ Broches
#define BROCHE_BOUTON           2
#define BROCHE_DEL_ROUGE        3     // doit être une sortie PWM (3, 5, 6, 9, 10 ou 11) pour analogWrite()
#define BROCHE_RELAIS           4
#define BROCHE_MOUVEMENT        5
#define BROCHE_DEL_VERTE        7
#define BROCHE_LIEN_TX          8     // vers le RX2 du MEGA
#define BROCHE_LIEN_RX          9     // depuis le TX2 du MEGA
#define BROCHE_POTENTIOMETRE    A0

// ------------------------------------------------------------------ Moniteur série
// Doit être égal à monitor_speed dans platformio.ini.
#define VITESSE_MONITEUR        115200

// ------------------------------------------------------------------ Délais (millisecondes)
// Chaque tâche de loop() a son propre rythme : aucune n'utilise delay().
#define DELAI_POTENTIOMETRE     100   // lecture du potentiomètre
#define DELAI_CAPTEURS          2000  // lecture du SHT31 et du BME280, puis envoi au MEGA
#define DELAI_HORLOGE           1000  // lecture de l'horloge RTC, puis envoi au MEGA
#define DELAI_LCD               500   // rafraîchissement du LCD RGB
#define DELAI_PAGE_LCD          2500  // le LCD alterne ses pages de mesures à ce rythme
#define DELAI_ANTI_REBOND       30    // un appui doit durer au moins ce temps pour compter
#define DUREE_MESSAGE_LCD       3000  // durée d'un message d'événement sur le LCD
#define DUREE_OUVERTURE_PORTE   3000  // badge accepté : le relais reste fermé ce temps

// ------------------------------------------------------------------ Seuils
// Le potentiomètre n'est renvoyé au MEGA que s'il a bougé d'au moins ce nombre de %,
// pour ne pas encombrer le lien avec le bruit de la lecture analogique.
#define ECART_POTENTIOMETRE     2

// ------------------------------------------------------------------ LCD RGB (16 colonnes, 2 lignes)
#define LCD_COLONNES            16
#define LCD_LIGNES              2
// Couleurs du rétroéclairage, en rouge, vert, bleu (0 à 255).
#define COULEUR_NORMALE         0, 90, 180     // bleu : tout va bien
#define COULEUR_ALERTE          255, 0, 0      // rouge : mouvement détecté, badge refusé
#define COULEUR_ACCES           0, 200, 60     // vert : badge accepté
#define COULEUR_BOUTON          255, 140, 0    // orange : le bouton vient d'être appuyé

#endif
