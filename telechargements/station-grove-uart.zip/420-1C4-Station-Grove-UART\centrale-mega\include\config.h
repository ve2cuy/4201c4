/*
 * =====================================================================
 *  config.h — Réglages de la centrale (carte MEGA)
 * ---------------------------------------------------------------------
 *  Cours 420-1C4 — Objets connectés                         Par VE2CUY
 *
 *  Tout ce qu'on peut vouloir changer est ici : les broches, les ports
 *  série, les délais, le réseau Wi-Fi, les badges autorisés.
 * =====================================================================
 *
 *  Branchements sur le hat « Grove Mega Shield » du MEGA
 *  ----------------------------------------------------
 *    Prise   Module                    Broche(s) / port utilisé
 *    D2      Afficheur 4-Digit         D2 (CLK) et D3 (DIO)
 *    D4      RGB LED Stick (10 DEL)    D4
 *    D6      Buzzer                    D6
 *    D8      DEL bleue                 D8
 *    UART1   Module Wi-Fi (ESP8266)    Serial1 (RX1 = 19, TX1 = 18)
 *    UART2   Câble vers le UNO         Serial2 (RX2 = 17, TX2 = 16)
 *    UART3   Lecteur RFID 125 kHz      Serial3 (RX3 = 15, TX3 = 14)
 *    I2C     LCD 20x4 I2C              SDA (D20) et SCL (D21), adresse 0x27
 *
 *  Le MEGA a QUATRE ports série matériels : Serial (le câble USB et le
 *  moniteur série), Serial1, Serial2 et Serial3. Contrairement au UNO, il
 *  n'a pas besoin de SoftwareSerial : chaque appareil série a son port.
 */

#ifndef CONFIG_H
#define CONFIG_H

// ------------------------------------------------------------------ Broches
#define BROCHE_4DIGIT_CLK       2
#define BROCHE_4DIGIT_DIO       3
#define BROCHE_BARRE_DEL        4
#define BROCHE_BUZZER           6
#define BROCHE_DEL_BLEUE        8

// ------------------------------------------------------------------ Ports série
#define VITESSE_MONITEUR        115200   // doit être égal à monitor_speed dans platformio.ini
#define PORT_WIFI               Serial1
#define VITESSE_WIFI            115200   // vitesse d'usine du module Grove UART WiFi
#define PORT_UNO                Serial2  // la vitesse est VITESSE_LIEN, dans protocole.h
#define PORT_RFID               Serial3
#define VITESSE_RFID            9600     // le lecteur Grove 125 kHz parle à 9600 bauds

// ------------------------------------------------------------------ LCD 20x4 I2C
#define LCD_ADRESSE             0x27     // 0x27 à la livraison (0x3F sur certains modules)
#define LCD_COLONNES            20
#define LCD_LIGNES              4

// ------------------------------------------------------------------ Barre de DEL
#define NB_DEL_BARRE            10
#define LUMINOSITE_BARRE        60       // 0 à 255 : les DEL sont très vives, on les ménage

// ------------------------------------------------------------------ Délais (millisecondes)
#define DELAI_LCD               500      // rafraîchissement du LCD 20x4
#define DELAI_AFFICHEUR         250      // rafraîchissement de l'afficheur 4-Digit
#define DELAI_BARRE             40       // une image de l'animation de la barre de DEL (25 par seconde)
#define DUREE_TEMOIN_BLEU       60       // la DEL bleue clignote ce temps à chaque message du UNO
#define DUREE_ALERTE            3000     // durée de l'alerte « mouvement »
#define DUREE_EFFET             1000     // durée d'un effet de la barre (bouton, badge)
#define DELAI_LIEN_PERDU        5000     // sans message du UNO pendant ce temps, le lien est « perdu »

// ------------------------------------------------------------------ Wi-Fi
// Dans le simulateur, n'importe quel nom de réseau et mot de passe est accepté.
// Sur un vrai module, mettre ceux du réseau de la classe.
#define WIFI_RESEAU             "Reseau-du-cours"
#define WIFI_MOT_DE_PASSE       "motdepasse"
// La page demandée par la commande « w » du menu (HTTP simple, port 80).
#define SITE_WEB                "example.com"
#define SITE_CHEMIN             "/"
#define DELAI_REPONSE_WEB       5000     // attente maximale de la réponse du site

// ------------------------------------------------------------------ RFID
// Un badge 125 kHz envoie 12 caractères hexadécimaux. Les badges autorisés
// sont listés ici. Le premier est le code proposé par défaut par le simulateur.
#define LONGUEUR_CODE_BADGE     12
const char *const BADGES_AUTORISES[] = {
  "2E008BA5AEAE",
  "0415AB12CD34",
};

#endif
