/*
 * =====================================================================
 *  Station Grove à deux Arduino — LA CENTRALE (carte MEGA)
 * ---------------------------------------------------------------------
 *  Cours 420-1C4 — Objets connectés                         Par VE2CUY
 *  Version 1.0 — 2026-11-20
 * =====================================================================
 *
 *  Rôle de cette carte
 *  -------------------
 *  Le MEGA est la « centrale » : il REÇOIT les mesures et les événements du
 *  poste de capteurs (le UNO), les AFFICHE (LCD 20x4, afficheur 4-Digit,
 *  barre de DEL), ALERTE (buzzer, DEL), CONTRÔLE L'ACCÈS (lecteur de badges
 *  RFID) et COMMUNIQUE avec Internet (module Wi-Fi). Il peut aussi
 *  commander le UNO : fermer son relais, allumer sa DEL verte.
 *
 *  Les modules de cette carte (voir config.h pour les broches)
 *  ----------------------------------------------------------
 *    Afficheur 4-Digit, RGB LED Stick, buzzer, DEL bleue, LCD 20x4 I2C,
 *    module Wi-Fi, lecteur RFID — et le câble vers le UNO.
 *
 *  Comment le programme est organisé
 *  ---------------------------------
 *  Comme sur le UNO, loop() appelle de petites TÂCHES qui ne bloquent jamais
 *  (voir estMomentDe()). Même le buzzer joue ses mélodies sans delay() :
 *  une tâche passe à la note suivante quand la précédente est finie.
 *
 *  Seule exception, volontaire : la requête Web (touche « w » du menu)
 *  attend la réponse du site, quelques secondes au plus. Pendant ce temps,
 *  les messages du UNO s'accumulent dans la mémoire du port Serial2 (64
 *  octets) : certains peuvent être perdus, ce qui est sans gravité ici,
 *  puisque le UNO renvoie ses mesures régulièrement.
 *
 *  Le menu (moniteur série, 115200 bauds) : « ? » l'affiche.
 *  Le protocole avec le UNO est décrit dans protocole.h.
 */

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>    // LCD 20x4 avec son adaptateur I2C (PCF8574)
#include <Adafruit_NeoPixel.h>    // RGB LED Stick : des DEL WS2812 « intelligentes »
#include "TM1637V2.h"             // Afficheur 4-Digit (bibliothèque du cours, dans lib/4Digit)
#include "WiFiEsp.h"              // Module Wi-Fi ESP8266, commandé par des commandes AT
#include "config.h"
#include "protocole.h"

// =====================================================================
//  Les objets qui représentent les modules
// =====================================================================

LiquidCrystal_I2C lcd(LCD_ADRESSE, LCD_COLONNES, LCD_LIGNES);
TM1637V2 afficheur(BROCHE_4DIGIT_CLK, BROCHE_4DIGIT_DIO);
Adafruit_NeoPixel barre(NB_DEL_BARRE, BROCHE_BARRE_DEL, NEO_GRB + NEO_KHZ800);
WiFiEspClient clientWeb;

// =====================================================================
//  L'état de la centrale
// =====================================================================

// --- Les modes d'affichage, choisis au menu ---
// Un « enum » donne un nom à chaque valeur possible : plus lisible qu'un 0, 1, 2...
enum ModeAfficheur { AFFICHEUR_HEURE, AFFICHEUR_POTENTIOMETRE, AFFICHEUR_TEMPERATURE, AFFICHEUR_ETEINT, NB_MODES_AFFICHEUR };
enum ModeBarre { BARRE_NIVEAU, BARRE_ARC_EN_CIEL, BARRE_ETEINTE, NB_MODES_BARRE };
// Un effet passager de la barre de DEL, qui remplace le mode pendant un moment.
enum EffetBarre { EFFET_AUCUN, EFFET_ALERTE, EFFET_ACCES, EFFET_REFUS, EFFET_BOUTON };

ModeAfficheur modeAfficheur = AFFICHEUR_HEURE;
ModeBarre     modeBarre     = BARRE_NIVEAU;
EffetBarre    effetBarre    = EFFET_AUCUN;
unsigned long finEffet      = 0;

bool temoinBleuActif   = true;    // la DEL bleue clignote-t-elle à chaque message du UNO? (menu 1)
bool buzzerActif       = true;    // menu 4
bool rfidActif         = true;    // menu r
bool retroEclairage    = true;    // menu 8
bool afficherTrafic    = false;   // afficher chaque message du UNO au moniteur? (menu v)
bool wifiDemarre       = false;   // le module Wi-Fi a-t-il été initialisé?

// --- Ce que le UNO nous a appris (ses derniers messages) ---
char  heureUno[9]      = "--:--:--";
float temperature      = NAN;
float humidite         = NAN;
float temperatureBme   = NAN;
float pression         = NAN;
int   potentiometre    = -1;
unsigned int nbAppuis  = 0;
bool  relaisUno        = false;
bool  verteUno         = false;

// --- Le lien avec le UNO ---
unsigned long dernierMessageUno = 0;
bool lienEtabli        = false;
unsigned int nbMessagesRecus = 0;

// --- Le dernier événement, affiché sur la 4e ligne du LCD ---
char dernierEvenement[LCD_COLONNES + 1] = "Demarrage...";

// =====================================================================
//  Outils
// =====================================================================

/** Vrai quand une tâche doit agir (même principe que sur le UNO : voir son main.cpp). */
bool estMomentDe(unsigned long &dernierPassage, unsigned long delai) {
  unsigned long maintenant = millis();
  if (maintenant - dernierPassage >= delai) {
    dernierPassage = maintenant;
    return true;
  }
  return false;
}

/** Vrai tant que l'instant `fin` n'est pas atteint. Le transtypage en (long) gère le retour à zéro de millis(). */
bool avant(unsigned long fin) {
  return (long)(millis() - fin) < 0;
}

/** Écrit un nombre à virgule dans une chaîne (snprintf ne le fait pas sur un Arduino). */
void nombreEnTexte(float valeur, byte decimales, char *texte) {
  if (isnan(valeur)) {
    strcpy(texte, "--");
  } else {
    dtostrf(valeur, 1, decimales, texte);
  }
}

/** Retient un événement : il s'affiche sur la 4e ligne du LCD et au moniteur série. */
void noterEvenement(const char *texte) {
  strncpy(dernierEvenement, texte, LCD_COLONNES);
  dernierEvenement[LCD_COLONNES] = '\0';
  Serial.print(F("* "));
  Serial.println(texte);
}

// =====================================================================
//  Le buzzer : des mélodies jouées sans bloquer
// =====================================================================

// Une note : sa fréquence en hertz (0 = silence) et sa durée en millisecondes.
struct Note {
  unsigned int frequence;
  unsigned int duree;
};

// Les mélodies. NB_NOTES() compte les notes d'un tableau.
#define NB_NOTES(melodie) (sizeof(melodie) / sizeof(melodie[0]))
const Note BIP_COURT[]      = { {1800, 80} };
const Note MELODIE_ACCES[]  = { {1047, 120}, {1319, 120}, {1568, 220} };            // do, mi, sol : ça monte
const Note MELODIE_REFUS[]  = { {440, 250}, {0, 80}, {330, 450} };                  // deux notes graves
const Note MELODIE_ALERTE[] = { {2200, 150}, {0, 100}, {2200, 150}, {0, 100},
                                {2200, 150}, {0, 100}, {2200, 150}, {0, 100},
                                {2200, 150}, {0, 100}, {2200, 150} };
const Note MELODIE_ESSAI[]  = { {523, 150}, {659, 150}, {784, 150}, {1047, 300} };

const Note *melodieEnCours = NULL;   // NULL : rien ne joue
byte nbNotesMelodie = 0;
byte noteSuivante = 0;
unsigned long finNote = 0;

/** Lance une mélodie; elle remplace celle qui joue peut-être déjà. */
void jouer(const Note *melodie, byte nbNotes) {
  if (!buzzerActif) {
    return;
  }
  melodieEnCours = melodie;
  nbNotesMelodie = nbNotes;
  noteSuivante = 0;
  finNote = millis();   // la première note part au prochain passage de la tâche
}

/**
 * TÂCHE : fait avancer la mélodie. tone(broche, fréquence) produit un signal
 * carré sur la broche jusqu'à noTone() : le buzzer sonne à cette fréquence.
 * Note : tone() utilise le Timer2 du microcontrôleur.
 */
void tacheBuzzer() {
  if (melodieEnCours == NULL || avant(finNote)) {
    return;
  }
  if (noteSuivante >= nbNotesMelodie) {   // dernière note terminée
    noTone(BROCHE_BUZZER);
    melodieEnCours = NULL;
    return;
  }
  Note note = melodieEnCours[noteSuivante++];
  if (note.frequence > 0) {
    tone(BROCHE_BUZZER, note.frequence);
  } else {
    noTone(BROCHE_BUZZER);
  }
  finNote = millis() + note.duree;
}

// =====================================================================
//  Le lien avec le UNO : envoyer et recevoir des messages
// =====================================================================

/** Envoie un message texte au UNO : « cle=valeur » et une fin de ligne. */
void envoyer(const char *cle, const char *valeur) {
  PORT_UNO.print(cle);
  PORT_UNO.print(SEPARATEUR);
  PORT_UNO.println(valeur);
}

void envoyer(const char *cle, long valeur) {
  char texte[12];
  ltoa(valeur, texte, 10);
  envoyer(cle, texte);
}

/** Accumule les caractères reçus du UNO; vrai quand un message complet est dans `message`. */
bool lireMessage(char *message) {
  static char tampon[LONGUEUR_MAX_MESSAGE + 1];
  static byte longueur = 0;

  while (PORT_UNO.available() > 0) {
    char c = PORT_UNO.read();
    if (c == '\r') {
      continue;
    }
    if (c == '\n') {
      tampon[longueur] = '\0';
      strcpy(message, tampon);
      longueur = 0;
      return true;
    }
    if (longueur < LONGUEUR_MAX_MESSAGE) {
      tampon[longueur++] = c;
    }
  }
  return false;
}

/** Lance un effet passager sur la barre de DEL. */
void lancerEffet(EffetBarre effet, unsigned long duree) {
  effetBarre = effet;
  finEffet = millis() + duree;
}

/** Exécute un message reçu du UNO. */
void traiterMessageUno(const char *cle, const char *valeur) {
  char texte[LCD_COLONNES + 1];

  if (strcmp(cle, MSG_TEMPERATURE) == 0) {
    temperature = atof(valeur);
  } else if (strcmp(cle, MSG_HUMIDITE) == 0) {
    humidite = atof(valeur);
  } else if (strcmp(cle, MSG_TEMP_BME) == 0) {
    temperatureBme = atof(valeur);
  } else if (strcmp(cle, MSG_PRESSION) == 0) {
    pression = atof(valeur);
  } else if (strcmp(cle, MSG_POTENTIOMETRE) == 0) {
    potentiometre = atoi(valeur);
  } else if (strcmp(cle, MSG_HEURE) == 0) {
    strncpy(heureUno, valeur, 8);
    heureUno[8] = '\0';
  } else if (strcmp(cle, MSG_ETAT_RELAIS) == 0) {
    relaisUno = atoi(valeur) == 1;
  } else if (strcmp(cle, MSG_ETAT_VERTE) == 0) {
    verteUno = atoi(valeur) == 1;
  } else if (strcmp(cle, MSG_BOUTON) == 0) {
    nbAppuis = atoi(valeur);
    snprintf(texte, sizeof(texte), "Bouton UNO : %u", nbAppuis);
    noterEvenement(texte);
    jouer(BIP_COURT, NB_NOTES(BIP_COURT));
    lancerEffet(EFFET_BOUTON, 300);
  } else if (strcmp(cle, MSG_MOUVEMENT) == 0) {
    noterEvenement("MOUVEMENT DETECTE!");
    jouer(MELODIE_ALERTE, NB_NOTES(MELODIE_ALERTE));
    lancerEffet(EFFET_ALERTE, DUREE_ALERTE);
  } else if (strcmp(cle, MSG_BONJOUR) == 0) {
    snprintf(texte, sizeof(texte), "UNO dit : %s", valeur);
    noterEvenement(texte);
  }
  // Une clé inconnue est simplement ignorée : c'est ce qui rend le protocole facile à agrandir.
}

/** TÂCHE : reçoit et traite les messages du UNO. */
void tacheLienUno() {
  char message[LONGUEUR_MAX_MESSAGE + 1];
  if (!lireMessage(message)) {
    return;
  }
  char *separateur = strchr(message, SEPARATEUR);
  if (separateur == NULL) {
    return;
  }
  *separateur = '\0';

  nbMessagesRecus++;
  dernierMessageUno = millis();
  if (!lienEtabli) {
    lienEtabli = true;
    noterEvenement("Lien UNO etabli");
  }
  // La DEL bleue clignote brièvement : le « témoin d'activité » du lien.
  if (temoinBleuActif) {
    digitalWrite(BROCHE_DEL_BLEUE, HIGH);
  }
  if (afficherTrafic) {
    Serial.print(F("<- UNO : "));
    Serial.print(message);
    Serial.print('=');
    Serial.println(separateur + 1);
  }
  traiterMessageUno(message, separateur + 1);
}

/** TÂCHE : éteint le témoin bleu, et détecte la perte du lien avec le UNO. */
void tacheSurveillanceLien() {
  if (millis() - dernierMessageUno >= DUREE_TEMOIN_BLEU) {
    digitalWrite(BROCHE_DEL_BLEUE, LOW);
  }
  // Le UNO envoie l'heure chaque seconde : un silence de plusieurs secondes est anormal.
  if (lienEtabli && millis() - dernierMessageUno >= DELAI_LIEN_PERDU) {
    lienEtabli = false;
    noterEvenement("Lien UNO perdu!");
  }
}

// =====================================================================
//  Le lecteur RFID
// =====================================================================

/** Vrai si le code fait partie des badges autorisés (config.h). */
bool badgeAutorise(const char *code) {
  for (byte i = 0; i < sizeof(BADGES_AUTORISES) / sizeof(BADGES_AUTORISES[0]); i++) {
    if (strcasecmp(code, BADGES_AUTORISES[i]) == 0) {   // strcasecmp : sans tenir compte des majuscules
      return true;
    }
  }
  return false;
}

void traiterBadge(const char *code) {
  char texte[LCD_COLONNES + 1];
  bool accepte = badgeAutorise(code);
  snprintf(texte, sizeof(texte), "%s %s", accepte ? "Accepte" : "Refuse ", code);
  noterEvenement(texte);
  envoyer(CMD_BADGE, accepte ? BADGE_ACCEPTE : BADGE_REFUSE);   // le UNO ouvre la porte, ou non
  if (accepte) {
    jouer(MELODIE_ACCES, NB_NOTES(MELODIE_ACCES));
    lancerEffet(EFFET_ACCES, DUREE_EFFET);
  } else {
    jouer(MELODIE_REFUS, NB_NOTES(MELODIE_REFUS));
    lancerEffet(EFFET_REFUS, DUREE_EFFET);
  }
}

/**
 * TÂCHE : lit le lecteur RFID. Quand on approche un badge, le lecteur Grove
 * 125 kHz envoie une TRAME de 14 octets :
 *
 *     0x02   12 caractères hexadécimaux (le code)   0x03
 *     début                                          fin
 *
 * On lit les octets un à un, à mesure qu'ils arrivent, et on ne traite le
 * code qu'une fois la trame complète et de la bonne longueur.
 */
void tacheRfid() {
  static char code[LONGUEUR_CODE_BADGE + 1];
  static byte longueur = 0;
  static bool dansTrame = false;

  while (PORT_RFID.available() > 0) {
    byte octet = PORT_RFID.read();
    if (octet == 0x02) {                 // début de trame
      dansTrame = true;
      longueur = 0;
    } else if (octet == 0x03) {          // fin de trame
      if (dansTrame && longueur == LONGUEUR_CODE_BADGE && rfidActif) {
        code[longueur] = '\0';
        traiterBadge(code);
      }
      dansTrame = false;
    } else if (dansTrame && longueur < LONGUEUR_CODE_BADGE) {
      code[longueur++] = octet;
    }
  }
}

// =====================================================================
//  Les afficheurs
// =====================================================================

/**
 * Écrit une ligne complète du LCD 20x4, complétée d'espaces (efface les
 * restes), mais SEULEMENT si elle a changé.
 *
 * Pourquoi? Avec l'adaptateur I2C, chaque caractère demande plusieurs
 * envois sur le bus I2C : réécrire les 80 caractères de l'écran occupe le
 * processeur plus d'un dixième de seconde. Pendant ce temps, les messages du
 * UNO s'accumulent dans le tampon de Serial2... qui peut déborder. On garde
 * donc une copie de ce qui est affiché, et on n'envoie que les lignes qui
 * ont changé (le plus souvent, seulement l'heure).
 */
void ecrireLigneLcd(byte ligne, const char *texte) {
  static char affiche[LCD_LIGNES][LCD_COLONNES + 1];   // ce qui est à l'écran, ligne par ligne
  char complete[LCD_COLONNES + 1];
  snprintf(complete, sizeof(complete), "%-20s", texte);
  if (strcmp(complete, affiche[ligne]) == 0) {
    return;                                            // déjà affiché : rien à faire
  }
  strcpy(affiche[ligne], complete);
  lcd.setCursor(0, ligne);
  lcd.print(complete);
}

/**
 * TÂCHE : rafraîchit le LCD 20x4.
 *   14:05:09   UNO: OK        l'heure du UNO, et l'état du lien
 *   Temp 23.4C  Hum 45%       le SHT31 du UNO
 *   Pres 1013.2 Pot  50%      le BME280 et le potentiomètre du UNO
 *   Accepte 2E008BA5AEAE      le dernier événement
 */
void tacheLcd() {
  static unsigned long dernierPassage = 0;
  if (!estMomentDe(dernierPassage, DELAI_LCD)) {
    return;
  }
  char ligne[LCD_COLONNES + 1];
  char a[10], b[10];

  snprintf(ligne, sizeof(ligne), "%s   UNO: %s", heureUno, lienEtabli ? "OK" : "--");
  ecrireLigneLcd(0, ligne);

  nombreEnTexte(temperature, 1, a);
  nombreEnTexte(humidite, 0, b);
  snprintf(ligne, sizeof(ligne), "Temp %sC  Hum %s%%", a, b);
  ecrireLigneLcd(1, ligne);

  nombreEnTexte(pression, 1, a);
  snprintf(ligne, sizeof(ligne), "Pres %-6s Pot %3d%%", a, potentiometre < 0 ? 0 : potentiometre);
  ecrireLigneLcd(2, ligne);

  ecrireLigneLcd(3, dernierEvenement);
}

/**
 * Affiche quatre « chiffres » sur l'afficheur 4-Digit. Chaque valeur est un
 * chiffre de 0 à 9, une lettre de 10 (A) à 15 (F), ou VIDE. On n'envoie rien
 * si l'affichage n'a pas changé : chaque envoi prend du temps au processeur.
 */
const int8_t VIDE = 0x7f;   // la valeur que la bibliothèque TM1637V2 affiche comme une case éteinte
void afficherQuatre(int8_t c0, int8_t c1, int8_t c2, int8_t c3, bool deuxPoints) {
  static int8_t avant[4] = { -1, -1, -1, -1 };
  static bool pointsAvant = false;
  int8_t chiffres[4] = { c0, c1, c2, c3 };
  if (memcmp(chiffres, avant, 4) == 0 && deuxPoints == pointsAvant) {
    return;
  }
  memcpy(avant, chiffres, 4);
  pointsAvant = deuxPoints;
  afficheur.point(deuxPoints);   // le « : » du milieu, appliqué aux prochains envois
  for (byte position = 0; position < 4; position++) {
    afficheur.display(position, chiffres[position]);
  }
}

/** Un nombre de 0 à 9999, aligné à droite, sans zéros inutiles devant. */
void afficherNombre(int nombre) {
  nombre = constrain(nombre, 0, 9999);
  int8_t c[4];
  for (int position = 3; position >= 0; position--) {
    c[position] = (nombre > 0 || position == 3) ? nombre % 10 : VIDE;
    nombre /= 10;
  }
  afficherQuatre(c[0], c[1], c[2], c[3], false);
}

/** TÂCHE : rafraîchit l'afficheur 4-Digit selon son mode (menu 2). */
void tacheAfficheur() {
  static unsigned long dernierPassage = 0;
  if (!estMomentDe(dernierPassage, DELAI_AFFICHEUR)) {
    return;
  }
  switch (modeAfficheur) {
    case AFFICHEUR_HEURE:
      if (heureUno[0] == '-') {
        afficherQuatre(VIDE, VIDE, VIDE, VIDE, true);
      } else {
        // « 14:05:09 » : les caractères '1','4' puis '0','5'. Retirer '0' donne le chiffre.
        // Le « : » clignote : allumé les secondes paires.
        bool secondePaire = (heureUno[7] - '0') % 2 == 0;
        afficherQuatre(heureUno[0] - '0', heureUno[1] - '0', heureUno[3] - '0', heureUno[4] - '0', secondePaire);
      }
      break;
    case AFFICHEUR_POTENTIOMETRE:
      afficherNombre(potentiometre < 0 ? 0 : potentiometre);
      break;
    case AFFICHEUR_TEMPERATURE:
      if (isnan(temperature)) {
        afficherQuatre(VIDE, VIDE, VIDE, 12, false);       // « ---C » n'existe pas : seulement le C
      } else {
        int degres = constrain((int)round(temperature), 0, 99);
        afficherQuatre(degres >= 10 ? degres / 10 : VIDE, degres % 10, 12, VIDE, false);   // « 23C » (12 = C)
      }
      break;
    case AFFICHEUR_ETEINT:
    default:
      afficherQuatre(VIDE, VIDE, VIDE, VIDE, false);
      break;
  }
}

/**
 * TÂCHE : anime la barre de 10 DEL. Chaque DEL reçoit une couleur (rouge,
 * vert, bleu), puis show() envoie les 10 couleurs d'un coup sur l'unique fil
 * de données. Un effet passager (alerte, badge, bouton) a priorité sur le mode.
 */
void tacheBarre() {
  static unsigned long dernierPassage = 0;
  if (!estMomentDe(dernierPassage, DELAI_BARRE)) {
    return;
  }
  if (effetBarre != EFFET_AUCUN && !avant(finEffet)) {
    effetBarre = EFFET_AUCUN;            // l'effet est terminé : retour au mode
  }

  for (int i = 0; i < NB_DEL_BARRE; i++) {
    uint32_t couleur = 0;                // 0 : DEL éteinte
    switch (effetBarre) {
      case EFFET_ALERTE:                 // rouge clignotant, 3 fois par seconde
        couleur = (millis() / 160) % 2 ? barre.Color(255, 0, 0) : 0;
        break;
      case EFFET_ACCES:
        couleur = barre.Color(0, 255, 0);
        break;
      case EFFET_REFUS:
        couleur = barre.Color(255, 0, 0);
        break;
      case EFFET_BOUTON:
        couleur = barre.Color(255, 140, 0);
        break;
      case EFFET_AUCUN:
        if (modeBarre == BARRE_NIVEAU && potentiometre >= 0) {
          // Un « bargraphe » : autant de DEL allumées que le potentiomètre l'indique,
          // du vert (à gauche) au rouge (à droite).
          int allumees = (potentiometre * NB_DEL_BARRE + 50) / 100;   // + 50 : arrondi
          if (i < allumees) {
            int rouge = 255L * i / (NB_DEL_BARRE - 1);
            couleur = barre.Color(rouge, 255 - rouge, 0);
          }
        } else if (modeBarre == BARRE_ARC_EN_CIEL) {
          // Les couleurs de l'arc-en-ciel défilent : la teinte (0 à 65535) avance avec le temps.
          uint16_t teinte = (millis() * 20) + (uint32_t)i * 65536L / NB_DEL_BARRE;
          couleur = barre.gamma32(barre.ColorHSV(teinte));
        }
        break;
    }
    barre.setPixelColor(i, couleur);
  }
  barre.show();
}

// =====================================================================
//  Le Wi-Fi : une requête à un site Web
// =====================================================================

/**
 * Se connecte au réseau Wi-Fi, demande une page à SITE_WEB et affiche la
 * première ligne de la réponse, par exemple « HTTP/1.1 200 OK » (200 : la
 * page existe). Cette fonction ATTEND le réseau : elle bloque quelques
 * secondes. C'est voulu, pour garder le code simple; voir l'en-tête du fichier.
 *
 * Le module Wi-Fi ne connaît pas le HTTP : la bibliothèque WiFiEsp lui
 * envoie des commandes « AT » (AT+CWJAP pour se joindre au réseau,
 * AT+CIPSTART pour ouvrir une connexion TCP...). La requête HTTP elle-même,
 * c'est nous qui l'écrivons, ligne par ligne, comme un navigateur.
 */
void interrogerSiteWeb() {
  ecrireLigneLcd(3, "WiFi: connexion...");
  if (!wifiDemarre) {
    PORT_WIFI.begin(VITESSE_WIFI);
    WiFi.init(&PORT_WIFI);
    wifiDemarre = true;
  }
  if (WiFi.status() == WL_NO_SHIELD) {
    noterEvenement("WiFi: module absent");
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    Serial.print(F("Connexion au reseau "));
    Serial.println(F(WIFI_RESEAU));
    WiFi.begin(WIFI_RESEAU, WIFI_MOT_DE_PASSE);
  }
  if (WiFi.status() != WL_CONNECTED) {
    noterEvenement("WiFi: reseau refuse");
    return;
  }
  Serial.print(F("Adresse IP de la centrale : "));
  Serial.println(WiFi.localIP());

  if (!clientWeb.connect(SITE_WEB, 80)) {
    noterEvenement("WiFi: site injoignable");
    return;
  }
  // La requête HTTP : une ligne de commande, des en-têtes, puis une ligne vide.
  clientWeb.print(F("GET "));
  clientWeb.print(F(SITE_CHEMIN));
  clientWeb.println(F(" HTTP/1.1"));
  clientWeb.print(F("Host: "));
  clientWeb.println(F(SITE_WEB));
  clientWeb.println(F("Connection: close"));   // le site fermera la connexion après sa réponse
  clientWeb.println();

  // La réponse : on garde la première ligne, et on compte les octets du reste.
  char premiereLigne[40] = "";
  byte longueur = 0;
  bool premiereLigneFinie = false;
  unsigned long octets = 0;
  unsigned long limite = millis() + DELAI_REPONSE_WEB;
  while (avant(limite) && (clientWeb.connected() || clientWeb.available())) {
    while (clientWeb.available()) {
      char c = clientWeb.read();
      octets++;
      if (!premiereLigneFinie) {
        if (c == '\r' || c == '\n') {
          premiereLigneFinie = true;
        } else if (longueur < sizeof(premiereLigne) - 1) {
          premiereLigne[longueur++] = c;
          premiereLigne[longueur] = '\0';
        }
      }
    }
  }
  clientWeb.stop();

  Serial.print(F("Reponse de " SITE_WEB " : "));
  Serial.println(premiereLigne);
  Serial.print(F("Octets recus : "));
  Serial.println(octets);

  // « HTTP/1.1 200 OK » : le code est le nombre après le premier espace.
  char texte[LCD_COLONNES + 1];
  const char *espace = strchr(premiereLigne, ' ');
  if (espace != NULL) {
    snprintf(texte, sizeof(texte), "WiFi: HTTP %d", atoi(espace + 1));
  } else {
    snprintf(texte, sizeof(texte), "WiFi: pas de reponse");
  }
  noterEvenement(texte);
}

// =====================================================================
//  Le menu du moniteur série
// =====================================================================

void afficherMenu() {
  Serial.println();
  Serial.println(F("================= CENTRALE (MEGA) ================="));
  Serial.println(F("  ?  Ce menu"));
  Serial.println(F("  e  Etat de tous les modules et donnees du UNO"));
  Serial.println(F("  1  DEL bleue (D8) : temoin du lien actif / eteint"));
  Serial.println(F("  2  Afficheur 4-Digit (D2) : mode suivant"));
  Serial.println(F("     (heure -> potentiometre -> temperature -> eteint)"));
  Serial.println(F("  3  Barre de DEL (D4) : mode suivant"));
  Serial.println(F("     (niveau du potentiometre -> arc-en-ciel -> eteinte)"));
  Serial.println(F("  4  Buzzer (D6) : actif / muet"));
  Serial.println(F("  5  Buzzer : jouer une melodie d'essai"));
  Serial.println(F("  6  Relais du UNO : fermer / ouvrir (commande a distance)"));
  Serial.println(F("  7  DEL verte du UNO : allumer / eteindre (commande a distance)"));
  Serial.println(F("  8  LCD 20x4 : retroeclairage allume / eteint"));
  Serial.println(F("  r  Lecteur RFID (UART3) : actif / ignore"));
  Serial.println(F("  u  Demander au UNO toutes ses mesures"));
  Serial.println(F("  v  Afficher les messages recus du UNO : oui / non"));
  Serial.println(F("  w  Wi-Fi (UART1) : se connecter et interroger " SITE_WEB));
  Serial.println(F("==================================================="));
}

void afficherEtatModule(const __FlashStringHelper *nom, bool actif) {
  Serial.print(nom);
  Serial.println(actif ? F("OUI") : F("non"));
}

void afficherEtat() {
  static const char *const NOMS_AFFICHEUR[] = { "heure", "potentiometre", "temperature", "eteint" };
  static const char *const NOMS_BARRE[] = { "niveau du potentiometre", "arc-en-ciel", "eteinte" };
  char texte[12];
  Serial.println();
  Serial.println(F("--- Etat de la centrale ---"));
  afficherEtatModule(F("Lien avec le UNO etabli .... "), lienEtabli);
  Serial.print(F("Messages recus du UNO ...... ")); Serial.println(nbMessagesRecus);
  afficherEtatModule(F("Temoin bleu actif .......... "), temoinBleuActif);
  Serial.print(F("Afficheur 4-Digit .......... ")); Serial.println(NOMS_AFFICHEUR[modeAfficheur]);
  Serial.print(F("Barre de DEL ............... ")); Serial.println(NOMS_BARRE[modeBarre]);
  afficherEtatModule(F("Buzzer actif ............... "), buzzerActif);
  afficherEtatModule(F("Retroeclairage du LCD ...... "), retroEclairage);
  afficherEtatModule(F("Lecteur RFID actif ......... "), rfidActif);
  afficherEtatModule(F("Wi-Fi connecte ............. "), wifiDemarre && WiFi.status() == WL_CONNECTED);
  Serial.println(F("--- Donnees du UNO ---"));
  Serial.print(F("Heure ...................... ")); Serial.println(heureUno);
  nombreEnTexte(temperature, 1, texte);
  Serial.print(F("Temperature (SHT31) ........ ")); Serial.print(texte); Serial.println(F(" C"));
  nombreEnTexte(humidite, 0, texte);
  Serial.print(F("Humidite (SHT31) ........... ")); Serial.print(texte); Serial.println(F(" %"));
  nombreEnTexte(temperatureBme, 1, texte);
  Serial.print(F("Temperature (BME280) ....... ")); Serial.print(texte); Serial.println(F(" C"));
  nombreEnTexte(pression, 1, texte);
  Serial.print(F("Pression (BME280) .......... ")); Serial.print(texte); Serial.println(F(" hPa"));
  Serial.print(F("Potentiometre .............. ")); Serial.print(potentiometre); Serial.println(F(" %"));
  Serial.print(F("Appuis sur le bouton ....... ")); Serial.println(nbAppuis);
  afficherEtatModule(F("Relais du UNO ferme ........ "), relaisUno);
  afficherEtatModule(F("DEL verte du UNO allumee ... "), verteUno);
}

/** TÂCHE : lit une touche du moniteur série et l'exécute. */
void tacheMenu() {
  if (Serial.available() == 0) {
    return;
  }
  char touche = Serial.read();
  switch (touche) {
    case '?': afficherMenu(); break;
    case 'e': afficherEtat(); break;
    case '1':
      temoinBleuActif = !temoinBleuActif;
      afficherEtatModule(F("Temoin bleu actif : "), temoinBleuActif);
      break;
    case '2':
      // Le mode suivant; après le dernier, on revient au premier (le « % » est le reste de la division).
      modeAfficheur = (ModeAfficheur)((modeAfficheur + 1) % NB_MODES_AFFICHEUR);
      afficherEtat();
      break;
    case '3':
      modeBarre = (ModeBarre)((modeBarre + 1) % NB_MODES_BARRE);
      afficherEtat();
      break;
    case '4':
      buzzerActif = !buzzerActif;
      if (!buzzerActif) {
        noTone(BROCHE_BUZZER);
        melodieEnCours = NULL;
      }
      afficherEtatModule(F("Buzzer actif : "), buzzerActif);
      break;
    case '5':
      jouer(MELODIE_ESSAI, NB_NOTES(MELODIE_ESSAI));
      break;
    case '6':
      envoyer(CMD_RELAIS, relaisUno ? 0L : 1L);   // le UNO répondra par son nouvel état
      Serial.println(relaisUno ? F("-> UNO : ouvrir le relais") : F("-> UNO : fermer le relais"));
      break;
    case '7':
      envoyer(CMD_VERTE, verteUno ? 0L : 1L);
      Serial.println(verteUno ? F("-> UNO : eteindre la DEL verte") : F("-> UNO : allumer la DEL verte"));
      break;
    case '8':
      retroEclairage = !retroEclairage;
      if (retroEclairage) {
        lcd.backlight();
      } else {
        lcd.noBacklight();
      }
      afficherEtatModule(F("Retroeclairage : "), retroEclairage);
      break;
    case 'r':
      rfidActif = !rfidActif;
      afficherEtatModule(F("Lecteur RFID actif : "), rfidActif);
      break;
    case 'u':
      envoyer(CMD_ETAT, "?");
      Serial.println(F("-> UNO : envoie toutes tes mesures"));
      break;
    case 'v':
      afficherTrafic = !afficherTrafic;
      afficherEtatModule(F("Afficher les messages du UNO : "), afficherTrafic);
      break;
    case 'w':
      interrogerSiteWeb();
      break;
    default:
      break;
  }
}

// =====================================================================
//  setup() et loop()
// =====================================================================

void setup() {
  Serial.begin(VITESSE_MONITEUR);
  PORT_UNO.begin(VITESSE_LIEN);
  PORT_RFID.begin(VITESSE_RFID);
  // Le port du Wi-Fi n'est ouvert qu'à la première requête (touche « w ») :
  // l'initialisation du module prend quelques secondes.

  pinMode(BROCHE_DEL_BLEUE, OUTPUT);
  pinMode(BROCHE_BUZZER, OUTPUT);

  lcd.init();
  lcd.backlight();
  ecrireLigneLcd(0, "Centrale MEGA");
  ecrireLigneLcd(1, "Station Grove UART");
  ecrireLigneLcd(2, "Par VE2CUY");

  afficheur.set(ECRAN_MOYEN);   // sans cet appel, l'afficheur reste éteint
  afficheur.begin();

  barre.begin();
  barre.setBrightness(LUMINOSITE_BARRE);
  barre.show();                 // toutes les DEL éteintes

  afficherMenu();
  envoyer(CMD_ETAT, "?");       // si le UNO tourne déjà, il renvoie toutes ses mesures
  jouer(BIP_COURT, NB_NOTES(BIP_COURT));
}

void loop() {
  tacheMenu();
  tacheLienUno();
  tacheSurveillanceLien();
  tacheRfid();
  tacheBuzzer();
  tacheAfficheur();
  tacheBarre();
  tacheLcd();
}
