/*
 * =====================================================================
 *  protocole.h — Le « langage » commun du UNO et du MEGA
 * ---------------------------------------------------------------------
 *  Cours 420-1C4 — Objets connectés                         Par VE2CUY
 *
 *  ATTENTION : ce fichier existe en DEUX exemplaires identiques, un dans
 *  chaque projet (poste-uno/include et centrale-mega/include). Si vous
 *  modifiez l'un, copiez-le dans l'autre : les deux cartes doivent parler
 *  exactement le même langage.
 * =====================================================================
 *
 *  Le principe
 *  -----------
 *  Les deux cartes échangent des MESSAGES TEXTE, un message par ligne :
 *
 *        CLE=valeur\r\n
 *
 *  Exemples réels :   TEMP=23.4    HEURE=14:05:09    BOUTON=3    BADGE=OK
 *
 *  Pourquoi du texte plutôt que des octets « bruts » (une structure) ?
 *    - on peut LIRE les messages : dans le moniteur série, à l'oscilloscope
 *      du simulateur (décodage UART), ou dans l'animation des bits du câble;
 *    - un message abîmé ou inconnu est simplement ignoré, sans décaler les
 *      suivants : la fin de ligne remet tout le monde d'accord;
 *    - on ajoute un nouveau message sans rien casser.
 *  Le prix à payer : un nombre comme 1013.2 prend 6 octets au lieu de 4.
 *  À 9600 bauds (environ 960 octets par seconde), c'est sans importance ici.
 *
 *  Le câble
 *  --------
 *  Câble Grove entre la prise D8 du UNO et la prise UART2 du MEGA :
 *    - UNO  : SoftwareSerial, RX = D9, TX = D8 (port série « logiciel »);
 *    - MEGA : Serial2, le deuxième port série matériel (RX2 = 17, TX2 = 16).
 *  Le TX de l'un va au RX de l'autre : le câble Grove croise les fils.
 */

#ifndef PROTOCOLE_H
#define PROTOCOLE_H

// Vitesse du lien entre les deux cartes, en bauds (bits par seconde).
// SoftwareSerial est fiable jusqu'à 57600 bauds sur le UNO; 9600 laisse de la marge.
#define VITESSE_LIEN            9600

// Longueur maximale d'un message, fin de ligne non comprise. Un message plus
// long est tronqué : prévoir large, mais la mémoire du UNO est petite (2 Ko).
#define LONGUEUR_MAX_MESSAGE    40

// Le caractère qui sépare la clé de la valeur.
#define SEPARATEUR              '='

// ---------------------------------------------------------------------
//  Messages envoyés par le UNO (poste de capteurs) vers le MEGA (centrale)
// ---------------------------------------------------------------------
#define MSG_TEMPERATURE   "TEMP"     // Température du SHT31, en °C, 1 décimale    TEMP=23.4
#define MSG_HUMIDITE      "HUM"      // Humidité du SHT31, en %, entier               HUM=45
#define MSG_TEMP_BME      "TBME"     // Température du BME280, en °C, 1 décimale    TBME=23.1
#define MSG_PRESSION      "PRES"     // Pression du BME280, en hPa, 1 décimale      PRES=1013.2
#define MSG_POTENTIOMETRE "POT"      // Position du potentiomètre, de 0 à 100 %       POT=50
#define MSG_HEURE         "HEURE"    // Heure de l'horloge RTC, HH:MM:SS           HEURE=14:05:09
#define MSG_BOUTON        "BOUTON"   // Le bouton vient d'être appuyé; nombre d'appuis BOUTON=3
#define MSG_MOUVEMENT     "MOUV"     // Le détecteur vient de voir un mouvement       MOUV=1
#define MSG_ETAT_RELAIS   "RELAIS"   // État du relais : 1 = fermé, 0 = ouvert       RELAIS=1
#define MSG_ETAT_VERTE    "VERTE"    // État de la DEL verte : 1 = allumée            VERTE=0
#define MSG_BONJOUR       "BONJOUR"  // Envoyé au démarrage du UNO                BONJOUR=UNO

// ---------------------------------------------------------------------
//  Messages envoyés par le MEGA (centrale) vers le UNO (poste de capteurs)
// ---------------------------------------------------------------------
#define CMD_RELAIS        "RELAIS"   // Ouvrir (0) ou fermer (1) le relais           RELAIS=1
#define CMD_VERTE         "VERTE"    // Éteindre (0) ou allumer (1) la DEL verte      VERTE=1
#define CMD_BADGE         "BADGE"    // Résultat de la lecture d'un badge RFID      BADGE=OK
#define BADGE_ACCEPTE     "OK"       //   ... badge autorisé : le UNO ouvre la « porte » (relais)
#define BADGE_REFUSE      "REFUSE"   //   ... badge inconnu
#define CMD_ETAT          "ETAT"     // Demande au UNO de renvoyer toutes ses mesures  ETAT=?

#endif
